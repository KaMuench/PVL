package tables.samples;

import tables.parser.Parser;
import tables.semantics.symbols.SemanticException;

public class ParseSample2 {

	public static void main(String[] args) throws SemanticException {
		
		Parser p = Parser.fromFile("samples/sample2.txt");
		
		p.entries();
		
		System.out.println(p.getSymbols());
		
	}

}
