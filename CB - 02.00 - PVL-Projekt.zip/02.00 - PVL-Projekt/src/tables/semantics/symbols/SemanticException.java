package tables.semantics.symbols;

@SuppressWarnings("serial")
public class SemanticException extends Exception {

	public SemanticException(String message) {
		super(message);
	}

}
