package statemachine;

@SuppressWarnings("serial")
public class StateMachineException extends RuntimeException {

	public StateMachineException(String msg) {
		super(msg);
	}
}
